package com.mindtree.mystay.admin.model;

import java.util.List;

public class Offer {

	private List<String> offers;
	private String operation;
	
	public List<String> getOffers() {
		return offers;
	}
	public void setOffers(List<String> offers) {
		this.offers = offers;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	
	
}
