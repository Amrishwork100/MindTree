package com.mindtree.mystay.catalog.service;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.mindtree.mystay.catalog.entity.AddressEntity;
import com.mindtree.mystay.catalog.entity.HotelEntity;
import com.mindtree.mystay.catalog.entity.RoomsEntity;
import com.mindtree.mystay.catalog.model.SearchRequest;
import com.mindtree.mystay.catalog.repository.CatalogServiceRepositoryImpl;

//@RunWith(MockitoJUnitRunner.Silent.class)
public class CatalogServiceTest {

//	@Mock
//	private CatalogServiceRepositoryImpl catalogServiceRepository;
//
//	@InjectMocks
//	private CatalogServiceImpl catalogService;

	public void getHotels() {

//		List<HotelEntity> hotelList = new ArrayList<>();
//		HotelEntity hotel1 = new HotelEntity();
//		hotel1.setHotelId("T1001");
//		hotel1.setHotelName("T-Hotel1");
//		hotel1.setDistance(10);
//		AddressEntity address1 = new AddressEntity();
//		address1.setCity("T-City");
//		address1.setState("T-State");
//		address1.setStreet("T-Street");
//		address1.setPin(713294);
//		hotel1.setAddress(address1);
//		List<String> offers = new ArrayList<>();
//		offers.add("Test Offer 1");
//		offers.add("Test Offer 2");
//		offers.add("Test Offer 3");
//		hotel1.setOffers(offers);
//		List<RoomsEntity> roomList = new ArrayList<>();
//		RoomsEntity room1 = new RoomsEntity();
//		room1.setRoomNo("T101");
//		room1.setPrice(500.0);
//		room1.setAvailability("Yes");
//		room1.setRoomType("semi-luxury");
//		List<String> services = new ArrayList<>();
//		services.add("Test service 1");
//		services.add("Test service 2");
//		services.add("Test service 3");
//		room1.setServices(services);
//		roomList.add(room1);
//		hotel1.setRooms(roomList);
//		hotelList.add(hotel1);
//		SearchRequest searchRequest = new SearchRequest();
//		searchRequest.setLocation("T-City");
//		when(catalogServiceRepository.getHotels(searchRequest)).thenReturn(hotelList);

	}

}
