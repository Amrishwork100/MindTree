package com.mindtree.mystay.catalog.exceptions;

/**
 * @author Abhishek Karmakar M1049319
 *
 */
public class HotelNotFound extends RuntimeException {

	public HotelNotFound(String message) {
		super(message);
	}

}
