**To start all services**

Run batch-files/start.bat file to start all microservices
Before starting batch file change the path of jar files in start.bat file as per your specific configuration

**To stop all the services**

Run batch-files/stop.bat file to stop all the services at a time

**Config-Server**

This service contains configuration files for all microservices. Name of each configuration file must be same as its service name (i.e. spring.application.name)


To run config server in local system change the following properties:
1. add spring.cloud.config.server.git.uri=local_path_to_config_files(file://C:/) in application.properties file of config-server
2. run below commands in the folder containing all config files:
    * git init
    * git add -A
    * git commit
3. Add spring.cloud.config.uri=http://localhost:8791 (port_no of config server) in bootstrap.properties

**Redis cache**

Download Redis server from https://github.com/dmajkic/redis/downloads and extract it and follow the steps :
1. Run redis-server.exe to start redis server
2. Run redis-cli.exe
3. Set password by executing the command: config set requirepass </your_password> (enter) (note: enter the password within double quotes)
4. Execute command: AUTH </your_password>(enter) 

