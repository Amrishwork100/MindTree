This is not an official Google project.

This repository contains example code for the Spring Cloud GCP lab.

The instructions are in [bit.ly/spring-gcp-lab](http://bit.ly/spring-gcp-lab)

